// js/main.js — menu mobile, formulaires, année du pied de page
(function () {
  // Menu mobile
  var toggle = document.querySelector('.nav-toggle');
  var menu = document.getElementById('menu');
  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      var open = menu.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && menu.classList.contains('is-open')) {
        menu.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
      }
    });
  }

  // Compte à rebours du bandeau de lancement
  document.querySelectorAll('[data-countdown]').forEach(function (el) {
    var parts = el.getAttribute('data-countdown').split('-');
    var launch = new Date(+parts[0], +parts[1] - 1, +parts[2]);
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var days = Math.round((launch - today) / 86400000);
    if (days > 1) el.textContent = 'J-' + days + ' : plus que ' + days + ' jours';
    else if (days === 1) el.textContent = 'J-1 : c’est demain !';
    else if (days === 0) el.textContent = 'C’est aujourd’hui !';
    else el.textContent = 'Bunch est lancé !';
  });

  // Année
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  // Formulaires : validation simple côté navigateur.
  // Aucun envoi réel tant qu'aucun service n'est branché (voir data-endpoint).
  var messages = {
    valueMissing: 'Ce champ est obligatoire.',
    typeMismatch: 'Vérifie ton adresse e-mail.',
    checkbox: 'Coche la case pour qu’on puisse te répondre.'
  };

  function errorFor(field) {
    if (field.validity.valid) return '';
    if (field.type === 'checkbox') return messages.checkbox;
    if (field.validity.typeMismatch) return messages.typeMismatch;
    return messages.valueMissing;
  }

  function showError(field) {
    var box = document.getElementById(field.id + '-error');
    var msg = errorFor(field);
    field.setAttribute('aria-invalid', msg ? 'true' : 'false');
    if (box) box.textContent = msg;
    return !msg;
  }

  document.querySelectorAll('form[data-bunch-form]').forEach(function (form) {
    form.setAttribute('novalidate', '');
    var status = document.getElementById(form.getAttribute('data-status'));
    var fields = form.querySelectorAll('input, select, textarea');

    fields.forEach(function (f) {
      f.addEventListener('blur', function () { if (f.getAttribute('aria-invalid')) showError(f); });
      f.addEventListener('change', function () { if (f.getAttribute('aria-invalid')) showError(f); });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var firstInvalid = null;
      fields.forEach(function (f) {
        if (!showError(f) && !firstInvalid) firstInvalid = f;
      });
      if (firstInvalid) {
        firstInvalid.focus();
        if (status) status.textContent = '';
        return;
      }
      if (status) status.textContent = form.getAttribute('data-success');
      form.reset();
      fields.forEach(function (f) { f.removeAttribute('aria-invalid'); });
    });
  });
})();
